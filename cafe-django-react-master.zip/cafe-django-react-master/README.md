[Cafe App starting point](https://medium.com/@christosstath10/a-story-about-django-react-and-a-cafe-restaurant-webapp-part-1-backend-337bb9b0311e).
